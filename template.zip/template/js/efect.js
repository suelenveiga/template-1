$(function() {
				//custom animations to use
				//in the transitions
				var animations		= ['right','left','top','bottom','rightFade','leftFade','topFade','bottomFade'];
				var total_anim		= animations.length;
				//just change this to one of your choice
				var easeType		= 'swing';
				//the speed of each transition
				var animSpeed		= 450;
				//caching
				var $hs_container	= $('#hs_container');
				var $hs_areas		= $hs_container.find('.hs_area');
				
				//first preload all images
                $hs_images          = $hs_container.find('img');
                var total_images    = $hs_images.length;
                var cnt             = 0;
                $hs_images.each(function(){
                    var $this = $(this);
                    $('<img/>').load(function(){
                        ++cnt;
                        if(cnt == total_images){
							$hs_areas.each(function(){
								var $area 		= $(this);
								//when the mouse enters the area we animate the current
								//image (random animation from array animations),
								//so that the next one gets visible.
								//"over" is a flag indicating if we can animate 
								//an area or not (we don't want 2 animations 
								//at the same time for each area)
								$area.data('over',true).bind('mouseenter',function(){
									if($area.data('over')){
										$area.data('over',false);
										//how many images in this area?
										var total		= $area.children().length;
										//visible image
										var $current 	= $area.find('img:visible');
										//index of visible image
										var idx_current = $current.index();
										//the next image that's going to be displayed.
										//either the next one, or the first one if the current is the last
										var $next		= (idx_current == total-1) ? $area.children(':first') : $current.next();
										//show next one (not yet visible)
										$next.show();
										//get a random animation
										var anim		= animations[Math.floor(Math.random()*total_anim)];
										switch(anim){
											//current slides out from the right
											case 'right':
												$current.animate({
													'left':$current.width()+'px'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'left'		: '0px'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
											//current slides out from the left
											case 'left':
												$current.animate({
													'left':-$current.width()+'px'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'left'		: '0px'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
											//current slides out from the top	
											case 'top':
												$current.animate({
													'top':-$current.height()+'px'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'top'		: '0px'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
											//current slides out from the bottom	
											case 'bottom':
												$current.animate({
													'top':$current.height()+'px'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'top'		: '0px'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
											//current slides out from the right	and fades out
											case 'rightFade':
												$current.animate({
													'left':$current.width()+'px',
													'opacity':'0'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'left'		: '0px',
														'opacity'	: '1'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
											//current slides out from the left and fades out	
											case 'leftFade':
												$current.animate({
													'left':-$current.width()+'px','opacity':'0'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'left'		: '0px',
														'opacity'	: '1'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
											//current slides out from the top and fades out	
											case 'topFade':
												$current.animate({
													'top':-$current.height()+'px',
													'opacity':'0'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'top'		: '0px',
														'opacity'	: '1'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
											//current slides out from the bottom and fades out	
											case 'bottomFade':
												$current.animate({
													'top':$current.height()+'px',
													'opacity':'0'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'top'		: '0px',
														'opacity'	: '1'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;		
											default:
												$current.animate({
													'left':-$current.width()+'px'
												},
												animSpeed,
												easeType,
												function(){
													$current.hide().css({
														'z-index'	: '1',
														'left'		: '0px'
													});
													$next.css('z-index','9999');
													$area.data('over',true);
												});
												break;
										}	
									}
								});
							});
							
							//when clicking the hs_container all areas get slided
							//(just for fun...you would probably want to enter the site
							//or something similar)
							$hs_container.bind('click',function(){
								$hs_areas.trigger('mouseenter');
							});
						}
					}).attr('src',$this.attr('src'));
				});			
				

			});
			
			$(function() {

				$(' #da-thumbs > li ').each( function() { $(this).hoverdir({
					hoverDelay : 75
				}); } );

			});


			$(function() {

				Boxgrid.init();
			
			});



			$.CircleEventManager 			= function( options, element ) {
	
				this.$el			= $( element );
				
				this._init( options );
				
			};
			
			$.CircleEventManager.defaults 	= {
				onMouseEnter	: function() { return false },
				onMouseLeave	: function() { return false },
				onClick			: function() { return false }
			};
			
			$.CircleEventManager.prototype 	= {
				_init 				: function( options ) {
					
					this.options 		= $.extend( true, {}, $.CircleEventManager.defaults, options );
					
					// set the default cursor on the element
					this.$el.css( 'cursor', 'default' );
					
					this._initEvents();
					
				},
				_initEvents			: function() {
					
					var _self	= this;
					
					this.$el.on({
						'mouseenter.circlemouse'	: function( event ) {
							
							var el	= $(event.target),
							
									  circleWidth	= el.outerWidth( true ),
									  circleHeight	= el.outerHeight( true ),
									  circleLeft	= el.offset().left,
									  circleTop		= el.offset().top,
									  circlePos		= {
										  x		: circleLeft + circleWidth / 2,
										  y		: circleTop + circleHeight / 2,
										  radius: circleWidth / 2
									  };
							
							// save cursor type
							var cursor	= 'default';
							
							if( _self.$el.css('cursor') === 'pointer' || _self.$el.is('a') )
								cursor = 'pointer';
								
							el.data( 'cursor', cursor );
							
							el.on( 'mousemove.circlemouse', function( event ) {
			
								var distance	= Math.sqrt( Math.pow( event.pageX - circlePos.x, 2 ) + Math.pow( event.pageY - circlePos.y, 2 ) );
								
								if( !Modernizr.borderradius ) {
									
									// inside element / circle
									el.css( 'cursor', el.data('cursor') ).data( 'inside', true );
									_self.options.onMouseEnter( _self.$el );
								
								}
								else {
								
									if( distance <= circlePos.radius && !el.data('inside') ) {
										
										// inside element / circle
										el.css( 'cursor', el.data('cursor') ).data( 'inside', true );
										_self.options.onMouseEnter( _self.$el );
										
									}
									else if( distance > circlePos.radius && el.data('inside') ) {
										
										// inside element / outside circle
										el.css( 'cursor', 'default' ).data( 'inside', false );
										_self.options.onMouseLeave( _self.$el );
									
									}
								
								}
							
							});	
							
						},
						'mouseleave.circlemouse'	: function( event ) {
							
							var el 	= $(event.target);
				
							el.off('mousemove');
							
							if( el.data( 'inside' ) ) {
							
								el.data( 'inside', false );
								_self.options.onMouseLeave( _self.$el );
							
							}
							
						},
						'click.circlemouse'			: function( event ) {
							
							// allow the click only when inside the circle
							
							var el 	= $(event.target);
							
							if( !el.data( 'inside' ) )
								return false;
							else
								_self.options.onClick( _self.$el );
							
						}
					});
					
				},
				destroy				: function() {
				
					this.$el.unbind('.circlemouse').removeData('inside').removeData('cursor');
			
				}
			};
			$('#circle').circlemouse({
				onMouseEnter	: function( el ) {
				
					el.addClass('ec-circle-hover');
				
				},
				onMouseLeave	: function( el ) {
					
					el.removeClass('ec-circle-hover');
					
				},
				onClick			: function( el ) {
					
					alert('clicked');
					
				}
			});

			var $ps_container		= $('#ps_container'),
			$ps_image_wrapper 	= $ps_container.find('.ps_image_wrapper'),
			$ps_next			= $ps_container.find('.ps_next'),
			$ps_prev			= $ps_container.find('.ps_prev'),
			$ps_nav				= $ps_container.find('.ps_nav'),
			$tooltip			= $ps_container.find('.ps_preview'),
			$ps_preview_wrapper = $tooltip.find('.ps_preview_wrapper'),
			$links				= $ps_nav.children('li').not($tooltip),
			total_images		= $links.length,
			currentHovered		= -1,
			current				= 0,
			$loader				= $('#loader');

			var ie 				= false;
if ($.browser.msie) {
	ie = true; // oh no sweet Jesus
}
if(!ie) // there is a God
	$tooltip.css({
		opacity	: 0
	}).show();

	/*first preload images (thumbs and large images)*/
var loaded	= 0;
$links.each(function(i){
	var $link 	= $(this);
	$link.find('a').preload({
		onComplete	: function(){
			++loaded;
			if(loaded == total_images){
				//all images preloaded,
				//show ps_container and initialize events
				$loader.hide();
				$ps_container.show();
				//when mouse enters the the dots,
				//show the tooltip,
				//when mouse leaves hide the tooltip,
				//clicking on one will display the respective image
				$links.bind('mouseenter',showTooltip)
					  .bind('mouseleave',hideTooltip)
					  .bind('click',showImage);
				//navigate through the images
				$ps_next.bind('click',nextImage);
				$ps_prev.bind('click',prevImage);
			}
		}
	});
});

